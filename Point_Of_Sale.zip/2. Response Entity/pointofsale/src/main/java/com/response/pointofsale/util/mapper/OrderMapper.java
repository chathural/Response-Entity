package com.response.pointofsale.util.mapper;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")

public interface OrderMapper {

}
