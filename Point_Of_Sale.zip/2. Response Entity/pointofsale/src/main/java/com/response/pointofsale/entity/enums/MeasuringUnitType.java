package com.response.pointofsale.entity.enums;

public enum MeasuringUnitType {
    KILO_GRAM,LITER,MILLILITER,NUMBER
}
